# -*- coding: utf-8 -*-
"""Fast rows on Home: every row with &widget=1 keeps a copy per profile. The copy is shown at once; when it is older
than its time (30 minutes for rows of your account, 6 hours for TMDB rows) the row is fetched again right after, in
the same run, and only when something changed the Home property lucent.video.widgets gets a new value.

For the skin: add &reload=$INFO[Window(Home).Property(lucent.video.widgets)] to a row's address, then Kodi fetches
the row again by itself when it changed. RunPlugin(plugin://plugin.video.lucent/?action=widgets_refresh) marks every
copy as old (for 'Refresh all rows')."""
import hashlib
import json
import os
import time

import util

PROPERTY = "lucent.video.widgets"
ACCOUNT = ("continue", "continue_movie", "continue_episode", "nextup", "watching", "watchlist_movie", "watchlist_tv", "collection_movie",
           "collection_tv", "traktlist", "floppylist", "mdblist", "calendar", "tonight", "alerts", "new_seasons", "marathon", "coming_watchlist")
ACCOUNT_AGE = 30 * 60
OTHER_AGE = 6 * 3600
SKIP = ("service_row", "service_catalog", "lib_newseasons", "lib_newepisodes", "kompas")
IGNORE = ("widget", "reload", "page")
MARKS = "widgets_marks.json"      # {"all": time, "account": time}: copies from before these times are old


def _folder():
    return os.path.join(util.PROFILE, "widgets", util.current_user())


def _key(params):
    clean = sorted((k, v) for k, v in params.items() if k not in IGNORE)
    return hashlib.md5(json.dumps(clean).encode("utf-8")).hexdigest()


def wanted(params):
    return params.get("widget") == "1" and params.get("action") == "list" and params.get("name") not in SKIP \
        and not str(params.get("name", "")).startswith(SKIP)


def _slim(meta):
    return {k: v for k, v in meta.items() if k != "gallery"}


def get(params):
    try:
        with open(os.path.join(_folder(), _key(params) + ".json"), encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return None


def put(params, titles, content, size=0):
    folder = _folder()
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, _key(params) + ".json")
    with open(path + ".tmp", "w", encoding="utf-8") as handle:
        json.dump({"at": time.time(), "titles": [_slim(t) for t in titles], "content": content, "size": size}, handle)
    os.replace(path + ".tmp", path)


def is_old(params, entry, size=0):
    if size and entry.get("size") != size:
        return True                             # you chose another number of titles per row
    marks = util.load_json(MARKS, {})
    account = params.get("name") in ACCOUNT
    age = ACCOUNT_AGE if account else OTHER_AGE
    at = entry.get("at", 0)
    return time.time() - at > age or at < marks.get("all", 0) or (account and at < marks.get("account", 0))


def emptied_by_you(params, entry):
    """A row of your account that you changed yourself after this copy was made (a resume point cleared, marked as
    watched): an empty answer is real then, not a hiccup of the account."""
    return params.get("name") in ACCOUNT and entry.get("at", 0) < util.load_json(MARKS, {}).get("account", 0)


def same(entry, titles, content):
    def ids(rows):                              # where you stopped counts too: a row with a new resume point is new
        return [(t.get("kind"), str(t.get("tmdb")), t.get("season"), t.get("episode"), round(float(t.get("resume_percent") or 0)))
                for t in rows]
    return entry.get("content") == content and ids(entry.get("titles") or []) == ids(titles)


def bump():
    util.HOME.setProperty(PROPERTY, str(int(time.time() * 1000)))


def after_watching():
    """A video was just stopped or watched: forget what the account said before (it may have been read again while
    the account was still taking in the scrobble) and mark the rows of your account as old, so they are fetched
    again. Runs twice after a video (15 and 75 seconds later): the account does not always know it at once."""
    import tracker
    tracker.forget_lists()
    mark_old(account_only=True)


def mark_old(account_only=False):
    marks = util.load_json(MARKS, {})
    marks["account" if account_only else "all"] = time.time()
    util.save_json(MARKS, marks)
    bump()




def refresh_all():
    """action=widgets_refresh."""
    mark_old(False)
