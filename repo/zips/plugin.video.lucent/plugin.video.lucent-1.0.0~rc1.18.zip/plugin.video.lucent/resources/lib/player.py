# -*- coding: utf-8 -*-
"""Finds sources, asks about resuming, and starts the video."""
import base64
import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcgui
import xbmcplugin

import dialogs
import items
import ranking
import scrapers
import tmdb
import tracker
import util

HANDOFF = "lucent.video.now"
RUN = "lucent.video.run"
LOCAL = "progress.json"
LAST_RELEASE = "last_release.json"
MIME = {"mkv": "video/x-matroska", "mp4": "video/mp4", "avi": "video/x-msvideo", "m2ts": "video/mp2t", "ts": "video/mp2t"}


def progress_key(meta):
    if meta.get("type", meta.get("kind")) == "movie":
        return "movie:%s" % meta["tmdb"]
    return "ep:%s:%s:%s" % (meta["tmdb"], meta["season"], meta["episode"])


def title_meta(kind, tmdb_id, season=None, episode=None):
    if kind == "movie":
        return tmdb.details("movie", tmdb_id)
    show = tmdb.details("tvshow", tmdb_id)
    if not show:
        return None
    rows = tmdb.season(tmdb_id, season).get("episodes") or []
    for raw in rows:
        if raw["episode_number"] == int(episode):
            meta = tmdb.episode_meta(show, raw)
            meta["season_count"] = max(meta.get("season_count") or 0, len(rows))   # the season itself is fresher
            return meta
    return None


def _fail(handle, text=None):
    if text:
        xbmcgui.Dialog().notification("Lucent", text, xbmcgui.NOTIFICATION_WARNING, 5000)
    if handle >= 0:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(offscreen=True))


def _no_finder(services):
    """A debrid account is filled in, but nothing finds sources for it: say so plainly and offer the setup step."""
    name = " / ".join(services)
    text = util.T("Je %s-account is ingevuld. Dat levert de film, maar Lucent heeft ook een zoeker nodig die de bronnen vindt: "
                  "een AIOStreams-adres (aan te raden), Easynews, of de add-on CocoScrapers.\n\nNu instellen?",
                  "Your %s account is filled in. It delivers the film, but Lucent also needs a finder that looks up the sources: "
                  "an AIOStreams address (recommended), Easynews, or the CocoScrapers add-on.\n\nSet it up now?") % name
    if xbmcgui.Dialog().yesno(util.T("Nog een zoeker nodig", "A finder is still needed"), text):
        import setup_ui
        setup_ui.open_setup("scrapers")


def link_works(source):
    if not scrapers.ready(source):
        return False
    return _answers(source)


def _answers(source, offset=0):
    """A tiny request (one byte) to see whether the link answers. Works with redirects to the debrid service."""
    url, _, extra = source["url"].partition("|")
    if url.startswith("lucentv://"):              # read by vfs.lucent: it works while its plan is there
        from nzb import vfs
        return vfs.exists(url)
    head = dict(urllib.parse.parse_qsl(extra))
    parts = urllib.parse.urlsplit(url)
    if parts.username:           # urllib does not read a login from the address
        login = "%s:%s" % (urllib.parse.unquote(parts.username), urllib.parse.unquote(parts.password or ""))
        head["Authorization"] = "Basic " + base64.b64encode(login.encode("utf-8")).decode("ascii")
        url = urllib.parse.urlunsplit((parts.scheme, parts.netloc.rsplit("@", 1)[1], parts.path, parts.query, ""))
    head.setdefault("User-Agent", "Lucent-Video/0.1")
    head["Range"] = "bytes=%d-%d" % (offset, offset)
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=head), timeout=10) as response:
            return response.status < 400
    except (urllib.error.URLError, OSError, ValueError):
        return False


def final_server(source):
    """Where the picture really comes from: the server name after all redirects (one byte is asked). Never the address."""
    url, _, extra = (source.get("url") or "").partition("|")
    if url.startswith("lucentv://"):
        return "Usenet (vfs.lucent)"
    head = dict(urllib.parse.parse_qsl(extra))
    head.setdefault("User-Agent", "Lucent-Video/0.1")
    head["Range"] = "bytes=0-0"
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=head), timeout=10) as response:
            return urllib.parse.urlsplit(response.geturl()).hostname or "?"
    except (urllib.error.URLError, OSError, ValueError) as error:
        return "? (%s)" % type(error).__name__


def first_working(sources, index):
    """The chosen source, or the next one that works when its link is dead."""
    needs_wait = any(s.get("resolve") for s in sources[index:index + 5])
    if needs_wait:
        xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        return _first(sources, index)
    finally:
        if needs_wait:
            xbmc.executebuiltin("Dialog.Close(busydialognocancel)")


def _first(sources, index):
    import learn
    for position in range(index, min(index + 5, len(sources))):
        if link_works(sources[position]):
            if position != index:
                util.notify(util.T("Link werkte niet, volgende bron gekozen", "Link failed, using the next source"))
            return sources[position]
        learn.record(learn.key(sources[position]), False)
    for source in sources[index:]:
        if scrapers.ready(source):
            return source
    return sources[index]


def ask_resume(meta):
    """Returns the second to start from, 0 from the beginning, or None when cancelled."""
    runtime = int(meta.get("runtime") or 0) * 60
    saved = util.load_json(LOCAL, {}).get(progress_key(meta)) or {}
    position = float(saved.get("position") or 0)
    if saved.get("total"):
        runtime = int(saved["total"])
    percent = tracker.resume_percent(meta["kind"], meta["tmdb"], meta.get("season"), meta.get("episode"))
    if percent and runtime:
        position = runtime * percent / 100.0
    if position < 60 or (runtime and position > runtime * 0.92):
        return 0
    if util.number("resume_mode", 0) == 1:
        return position
    answer = dialogs.ask_resume(meta, items.clock(position), position * 100.0 / runtime if runtime else 0)
    return None if answer is None else (position if answer else 0)


def build(meta, source, resume=0):
    """The item Kodi plays. With a resume point Kodi opens the video at that place itself, before the picture starts:
    jumping there afterwards (while the TV switches its refresh rate) can leave the picture standing still."""
    url = source["url"]
    item = xbmcgui.ListItem(meta["title"], path=url, offscreen=True)
    item.setArt(items.art_of(meta))
    total = float(meta.get("runtime") or 0) * 60
    # Kodi reports the default id as "the IMDb number": other add-ons (like PunchPlay) read that while playing
    items.fill_tag(item, meta, default_id="imdb", resume=(resume, max(total, resume + 1)) if resume else None)
    if resume:
        item.setProperty("StartOffset", "%.1f" % float(resume))
    item.setProperty("IsPlayable", "true")
    if meta["kind"] == "episode":      # read by Lucent Ondertitels and TheIntroDB
        for key in ("tmdb", "imdb", "tvdb"):
            if meta.get(key):
                item.setProperty("tvshow.%s_id" % key, str(meta[key]))
    extension = source["name"].rsplit(".", 1)[-1].lower()
    if extension in MIME:             # saves Kodi an extra request to the link
        item.setMimeType(MIME[extension])
        item.setContentLookup(False)
    return item


def _trailer_playing():
    if util.HOME.getProperty("nuvio.trailer.active"):
        return True
    if not xbmc.getCondVisibility("Player.HasMedia"):
        return False
    try:
        return "plugin.video.youtube" in xbmc.Player().getPlayingFile()
    except RuntimeError:
        return False


def _no_trailer(limit=3.0):
    """The Lucent skin plays trailers on posters. A trailer still stopping while the film starts can disturb the
    switch to Dolby Vision on some boxes, so stop it and wait until it is really gone (at most a few seconds).
    The skin sets Home property nuvio.trailer.active while a trailer is on."""
    if not _trailer_playing():
        return
    xbmc.executebuiltin("PlayerControl(Stop)")
    monitor, waited = xbmc.Monitor(), 0.0
    while waited < limit and _trailer_playing():
        if monitor.waitForAbort(0.1):
            return
        waited += 0.1
    util.log("trailer stopped before the film (%.1fs)" % waited)


def lighter_than(source, order):
    """Up to three sources that are much smaller than the one playing, for when it keeps buffering."""
    size = source.get("size") or 0
    if not size:
        return []
    return [s for s in order if s is not source and s.get("cached") and 0 < (s.get("size") or 0) < size * 0.55][:3]


def describe(source):
    """What a source is, for the log: service, quality, size and the server's name. Never the address itself."""
    import urllib.parse
    url = source.get("url") or ""
    host = "vfs.lucent" if url.startswith("lucentv://") else urllib.parse.urlsplit(url).hostname or "?"
    scraper = (source.get("resolve") or {}).get("scraper") or ""
    parts = [scraper, source.get("service") or "", source.get("resolution") or "", streams_size(source.get("size")), "server " + host]
    return " / ".join(p for p in parts if p)


def streams_size(size):
    try:
        return "%.1f GB" % (float(size) / 1e9) if size else ""
    except (TypeError, ValueError):
        return ""


def _release_name(source):
    """The release name for the skin's player info (file and container): only the name, never a link, key or user."""
    name = (source.get("name") or "").strip().splitlines()[0] if (source.get("name") or "").strip() else ""
    if "://" in name or "?" in name or "@" in name:
        name = ""                                   # looks like a link or an address: leave it out
    return name.replace("\\", "/").rsplit("/", 1)[-1][:200]


def handoff(meta, resume, source, alternates=None, others=None, lighter=None, last=False):
    keep = ("kind", "tmdb", "imdb", "season", "episode", "title", "runtime", "show", "year")
    now = {k: meta.get(k) for k in keep}
    import learn
    now.update(resume=resume, started=time.time(), alternates=alternates or [], url=source.get("url"), size=source.get("size") or 0,
               learn=learn.key(source), together=others or [], lighter=lighter or [], bedtime_last=bool(last),
               name=_release_name(source))
    util.HOME.setProperty(HANDOFF, json.dumps(now))
    return now


def cannot_play(source):
    """Does this device, by the setting 'Dolby Vision on this device', not handle this source?"""
    support = util.number("dv_support", 0)
    tags = ranking.tags_of(source)
    return (support == 1 and bool(tags & {"fel", "p7"})) or (support == 2 and "dv" in tags)


def same_release_first(meta, sources):
    """A series keeps the release group and quality of the previous episode, so sound and language do not jump."""
    if meta["kind"] != "episode" or not util.flag("same_release"):
        return sources
    last = util.load_json(LAST_RELEASE, {}).get(str(meta["tmdb"]))
    if not last:
        return sources
    return sorted(sources, key=lambda s: 0 if (ranking.release_group(s) or "").lower() == last["group"] and s["resolution"] == last["res"] else 1)


def torbox_uncached(source):
    """A release TorBox does not have yet: playing it makes TorBox download it for your account, and TorBox can give a
    copyright strike for such requests (November 2026). Never started on its own; only after you said yes."""
    if source.get("cached") is not False:
        return False
    service = str(source.get("service") or "").upper()
    return "TORBOX" in service or (source.get("resolve") or {}).get("service") == "torbox"


def ask_torbox_uncached():
    return xbmcgui.Dialog().yesno("TorBox", util.T(
        "Deze release staat nog niet bij TorBox. TorBox moet hem eerst zelf downloaden, en dat kan een waarschuwing "
        "(strike) van TorBox opleveren. Toch doorgaan?",
        "TorBox does not have this release yet. TorBox has to download it first, and that can give you a warning "
        "(strike) from TorBox. Go on anyway?"))


def _usable(sources):
    """What may start without asking: cached first (or everything with 'include uncached' on, or when nothing is
    cached), but never a release TorBox would have to download."""
    usable = sources if util.flag("include_uncached") or not any(s["cached"] for s in sources) else [s for s in sources if s["cached"]]
    return [s for s in usable if not torbox_uncached(s)]


def would_play(meta, sources):
    """The source play() would start on its own for these sources (the first of the same order), or None."""
    usable = _usable(sources)
    usable = [s for s in usable if not cannot_play(s)] or usable
    order = same_release_first(meta, usable)
    return order[0] if order else None


def remember_release(meta, source):
    group = ranking.release_group(source)
    if meta["kind"] == "episode" and group:
        saved = util.load_json(LAST_RELEASE, {})
        saved[str(meta["tmdb"])] = {"group": group.lower(), "res": source["resolution"]}
        util.save_json(LAST_RELEASE, saved)


def link_is_dead(now, position, total):
    """Kodi reports a stream that broke the same as you pressing stop. So: does the link still answer at this point?"""
    if not now.get("url") or not total:
        return False
    return not _answers({"url": now["url"]}, int((now.get("size") or 0) * position / total))


def resume_elsewhere(now, position, lighter=False):
    """The link broke (or kept buffering: lighter=True). Starts the next source at the same place. True when one was started."""
    alternates = (now.get("lighter") if lighter else now.get("alternates")) or []
    full = None
    while alternates:
        source = alternates.pop(0)
        if not scrapers.ready(source) or not _answers(source):
            continue
        full = full or title_meta(now["kind"], now["tmdb"], now.get("season"), now.get("episode"))
        if not full:
            return False
        handoff(full, position, source, alternates, now.get("together"))
        util.log("%s at %ds: now %s" % ("lighter version" if lighter else "link dropped", int(position), describe(source)))
        import learn
        learn.record(now.get("learn"), False)          # the one that broke
        util.notify(util.T("Verder met een lichtere versie", "Continuing with a lighter version") if lighter else
                    util.T("Link viel weg, verder met een andere bron", "Link dropped, continuing with another source"))
        xbmc.Player().play(source["url"], build(full, source, position))
        return True
    return False


def find(meta_out, params):
    """Runs next to the 'Finding sources' screen. Fills meta_out['meta'] and meta_out['sources'] or meta_out['error']."""
    kind, tmdb_id = params.get("type"), params.get("tmdb")
    season, episode = params.get("season"), params.get("episode")
    try:
        meta = meta_out["meta"] = title_meta(kind, tmdb_id, season and int(season), episode and int(episode))
    except util.HttpError:
        meta = None
    if not meta:
        meta_out["error"] = util.T("Titel niet gevonden", "Title not found")
        return
    meta_out["ready"] = True
    try:
        sources, problem = scrapers.search(meta)
    except Exception as error:                  # noqa: BLE001 - a surprise while searching is not 'no scraper set up'
        util.log("search: %s: %s" % (type(error).__name__, error))
        meta_out["error"] = util.T("Zoeken mislukt door een fout. Probeer het opnieuw.", "The search failed with an error. Try again.")
        return
    if problem == "failed":
        meta_out["error"] = util.T("Geen scraper bereikbaar", "No scraper could be reached")
    elif problem == "address":
        meta_out["error"] = "address"
    elif problem == "off":
        meta_out["error"] = util.T("In je profiel '%s' staan al je scrapers uit. Zet er een aan of kies een ander profiel.",
                                   "All your scrapers are switched off in your profile '%s'. Switch one on or pick another profile.") % (
                                       __import__("ranking").active().get("name") or "")
    else:
        meta_out["sources"] = sources


def search_with_screen(params, before=None):
    """Shows the screen while searching. Returns (meta, sources), or None when cancelled or failed. 'before' runs right
    after the search started (the 'previous time' recap), so the search goes on meanwhile."""
    out = {}
    begun = time.time()
    worker = threading.Thread(target=find, args=(out, params), daemon=True)
    worker.start()
    if before:
        try:
            before()
        except Exception as error:          # noqa: BLE001 - a recap must never stop playback
            util.log("before search: %s" % type(error).__name__)
    monitor = xbmc.Monitor()
    while worker.is_alive() and "ready" not in out and not monitor.waitForAbort(0.05):
        pass
    screen = dialogs.busy_dialog(out.get("meta"))
    started, limit = time.time(), max(5, util.number("timeout", 30))
    tick = 0
    while worker.is_alive() and not screen.cancelled and not monitor.waitForAbort(0.1):
        screen.percent(min(90, (time.time() - started) * 90.0 / limit))
        tick += 1
        if tick % 3 == 0:                       # a few times a second: which scraper found how many so far
            screen.live(scrapers.LIVE)
    if screen.cancelled:
        return None, "cancelled"
    if out.get("error") or out.get("sources") is None:
        screen.close()
        # only 'address' when the scrapers really said they are not set up; anything else is a failed search
        return None, out.get("error") or util.T("Zoeken mislukt. Probeer het opnieuw.", "The search failed. Try again.")
    screen.live(scrapers.LIVE, final=True)
    dialogs.SEARCH_DONE["at"] = time.time()
    util.log("search: %d sources after %.1f s" % (len(out["sources"]), time.time() - begun))
    screen.done(out["sources"])
    if out["sources"]:
        monitor.waitForAbort(0.8)
    screen.close()
    return out["meta"], out["sources"]


ASK_RESUME = "lucent.video.askresume"     # set by the skin (2.1.21+) when it started a library item with 'noresume'


def play(params, handle):
    autoplay = params.get("autoplay") == "1"
    # read and wipe at once, whatever happens next: it is meant for this one title only
    skin_asks = util.HOME.getProperty(ASK_RESUME) == "1"
    util.HOME.clearProperty(ASK_RESUME)
    if not autoplay:
        util.HOME.clearProperty(RUN)
    if params.get("type") in ("movie", "episode", "tvshow"):
        import kids
        if kids.limit():
            check = tmdb.details("movie" if params["type"] == "movie" else "tvshow", params["tmdb"])
            if not check or not kids.allowed(check):
                return _fail(handle, util.T("Dit profiel mag deze titel niet kijken", "This profile may not watch this title"))
    if not autoplay and params.get("select") != "1" and params.get("type") in ("movie", "episode"):
        import abo
        try:
            first_meta = title_meta(params["type"], params["tmdb"], params.get("season") and int(params["season"]), params.get("episode") and int(params["episode"]))
        except util.HttpError:
            first_meta = None
        if first_meta and abo.offer(first_meta):
            return _fail(handle)
    import bedtime
    if params.get("type") in ("movie", "episode"):
        try:
            planned = title_meta(params["type"], params["tmdb"], params.get("season") and int(params["season"]), params.get("episode") and int(params["episode"]))
        except util.HttpError:
            planned = None
        allowed, last = bedtime.check(planned or {})
        if not allowed:
            return _fail(handle)
    else:
        last = False
    import together
    others = together.ask(params)
    import prefetch
    meta, sources = prefetch.take(params) if params.get("select") != "1" else (None, None)
    import lasttime
    recap = lambda: lasttime.show(params, planned if params.get("type") == "episode" else None)     # noqa: E731
    if meta is None:
        meta, sources = search_with_screen(params, before=recap)
    else:
        recap()
    if meta is None:
        if sources == "cancelled":
            return _fail(handle)
        if sources == "address":
            missing = scrapers.finder_missing()
            if missing:
                _fail(handle)
                return _no_finder(missing)
            return _fail(handle, util.T("Stel eerst een scraper in, zoals AIOStreams, Easynews of Usenet", "Set up a scraper first, such as AIOStreams, Easynews or Usenet"))
        return _fail(handle, sources)
    if not sources:
        return _fail(handle, util.T("Geen bronnen over. Kijk naar je filters of probeer een ander profiel.", "No sources left. Check your filters or try another profile."))

    usable = _usable(sources)
    for source in sources:
        source["cannot"] = cannot_play(source)
    usable = [s for s in usable if not s["cannot"]] or usable
    if params.get("select") == "1" or (util.number("play_mode", 0) == 1 and not autoplay):
        chosen = dialogs.choose_source(meta, sources, util.flag("include_uncached"))
        if not chosen:
            return _fail(handle)
        if chosen["cannot"] and not xbmcgui.Dialog().yesno("Lucent", util.T("Dit apparaat kan deze bron volgens je instelling niet goed afspelen. Toch proberen?",
                                                                            "This device may not play this source properly, according to your setting. Try anyway?")):
            return _fail(handle)
        if torbox_uncached(chosen) and not ask_torbox_uncached():
            return _fail(handle)
        order = [chosen] + [s for s in usable if s is not chosen]
    else:
        order = same_release_first(meta, usable)
        if not order:
            return _fail(handle, util.T("Alleen releases die TorBox nog moet downloaden. Kies er zelf een via 'Bron kiezen'.",
                                        "Only releases TorBox still has to download. Pick one yourself with 'Choose source'."))
    # from the library Kodi itself asks about resuming (asking again would be a second pop-up), unless the skin started
    # it with 'noresume' and asked us to show our own resume screen instead
    library_kodi_asked = params.get("lib") == "1" and not skin_asks
    resume = 0 if autoplay or library_kodi_asked or params.get("kodi_resumes") == "1" else ask_resume(meta)
    if resume is None:
        return _fail(handle)

    source = first_working(order, 0)
    if not source.get("url"):
        return _fail(handle, util.T("Deze bron kon niet worden gestart", "This source could not be started"))
    item = build(meta, source, resume)
    remember_release(meta, source)
    handoff(meta, resume, source, [s for s in order if s is not source][:4], others, lighter_than(source, order), last)
    bedtime.counted()
    util.log("playing %s: %s%s" % (progress_key(meta), describe(source), ", resume at %ds" % int(resume) if resume else ""))
    _no_trailer()
    if handle >= 0:
        xbmcplugin.setResolvedUrl(handle, True, item)
    else:
        xbmc.Player().play(source["url"], item)
    return None
