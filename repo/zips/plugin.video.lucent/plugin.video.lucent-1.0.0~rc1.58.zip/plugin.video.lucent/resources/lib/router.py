# -*- coding: utf-8 -*-
"""Every menu and action of the add-on. The Lucent skin can use these same addresses."""
import datetime
import time
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

import items
import kids
import floppy
import mdblist
import simkl
import tmdb
import tracker
import trakt
import users
import util

library, player, report, usenet, streams = (util.lazy(n) for n in ("library", "player", "report", "usenet", "streams"))


def ThreadPoolExecutor(*args, **kwargs):
    """concurrent.futures, loaded on first use: it pulls in logging, which slows every Home row's start on a small box."""
    from concurrent.futures import ThreadPoolExecutor as pool
    return pool(*args, **kwargs)


T = util.T
PAGE = 40
TMDB_LISTS = {
    "trending_movie": ("trending/movie/week", "movie"), "popular_movie": ("movie/popular", "movie"),
    "toprated_movie": ("movie/top_rated", "movie"), "nowplaying_movie": ("movie/now_playing", "movie"),
"trending_tv": ("trending/tv/week", "tvshow"),
    "popular_tv": ("tv/popular", "tvshow"), "toprated_tv": ("tv/top_rated", "tvshow"),
    "airing_tv": ("tv/on_the_air", "tvshow"),
}
ACCOUNT_LISTS = ("watchlist_movie", "watchlist_tv", "collection_movie", "collection_tv")


def send(handle, rows, content="", more=None):
    if more:
        url, item, folder = items.folder(T("Volgende pagina", "Next page"), more, "DefaultFolder.png")
        item.setProperty("SpecialSort", "bottom")          # always last, however the skin sorts the row
        rows.append((url, item, folder))
    xbmcplugin.addDirectoryItems(handle, rows, len(rows))
    if content:
        xbmcplugin.setContent(handle, content)
    else:                                       # a menu: in the order Lucent gives, no 'Date' or 'Name' sorting
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
    if handle >= 0 and xbmc.getCondVisibility("Skin.HasSetting(lucent.view.remember.off)"):
        import views                            # Settings > General > Views, when the skin does not do it itself
        views.apply(content)


PROGRESS = "progress.json"     # player.LOCAL; named here so a Home row does not have to load the whole player


def _progress_key(meta):
    """player.progress_key, without loading the player."""
    if meta.get("type", meta.get("kind")) == "movie":
        return "movie:%s" % meta["tmdb"]
    return "ep:%s:%s:%s" % (meta["tmdb"], meta["season"], meta["episode"])


def _resume_table():
    """{key: (position, total)} from this device and from Trakt; Trakt wins."""
    table = {k: (v.get("position", 0), v.get("total", 0)) for k, v in util.load_json(PROGRESS, {}).items() if v.get("total")}
    return table


def _resume_for(meta, table, paused):
    if meta["kind"] not in ("movie", "episode"):
        return None
    runtime = int(meta.get("runtime") or 0) * 60
    percent = paused.get(_progress_key(meta))
    if percent and runtime:
        return runtime * percent / 100.0, runtime
    return table.get(_progress_key(meta))


def _paused_table():
    table = {}
    for row in tracker.paused():
        if row.get("type") == "movie":
            table["movie:%s" % row["movie"]["ids"].get("tmdb")] = row.get("progress") or 0
        elif row.get("type") == "episode":
            table["ep:%s:%s:%s" % (row["show"]["ids"].get("tmdb"), row["episode"]["season"], row["episode"]["number"])] = row.get("progress") or 0
    return table


def send_titles(handle, titles, content, more=None):
    clock = time.time()
    titles = kids.keep(titles)
    tracker.enrich(titles)
    enriched = time.time()
    kinds = {meta["kind"] for meta in titles}     # only the tables this row needs: each can mean a big file or a call
    films = tracker.watched_movies() if "movie" in kinds else {}
    shows = tracker.watched_episodes() if kinds & {"episode", "tvshow"} else {}
    playable = kinds & {"movie", "episode"}
    local, paused = (_resume_table(), _paused_table()) if playable else ({}, {})
    tables = time.time()
    rows = []
    for meta in titles:
        last, counts, seen = "", None, False
        if meta["kind"] == "movie":
            seen, last = meta["tmdb"] in films, films.get(meta["tmdb"], "")
        elif meta["kind"] == "episode":
            when = shows.get(meta["tmdb"], {}).get((int(meta["season"]), int(meta["episode"])))
            seen, last = when is not None, when or ""
        else:
            shown = shows.get(meta["tmdb"], {})
            aired = meta.get("aired") if meta.get("aired") is not None else meta.get("episodes")
            counts = (aired or 0, len([key for key in shown if key[0] > 0]))     # only episodes that were on TV
            seen, last = bool(counts[0]) and counts[1] >= counts[0], max(shown.values()) if shown else ""
        row = items.title_item(meta, seen, _resume_for(meta, local, paused), last, counts)
        if meta["kind"] == "tvshow":
            _progress(row[1], meta, shows.get(meta["tmdb"], {}))
        rows.append(row)
    built = time.time()
    send(handle, rows, content, more)
    TIMES.update(enrich=enriched - clock, tables=tables - enriched, build=built - tables, send=time.time() - built)


TIMES = {}
STARTED = None


def _row_time(name, how, began):
    """Measured: how long a Home row took, and where the time went (for the report)."""
    parts = " ".join("%s %d" % (k, v * 1000) for k, v in TIMES.items())
    start = " start %d" % ((began - STARTED) * 1000) if STARTED else ""
    util.log("row %s: %s, %d ms (%s%s)" % (name, how, (time.time() - (STARTED or began)) * 1000, parts, start))


def _progress(item, meta, shown):
    """For the skin, on a series you started: lucent.left ('3 episodes to go' or 'All seen'), lucent.progress
    ('S2 · 5 of 10': the season you are in) and lucent.percent (0-100, the whole series)."""
    if not shown:
        return
    total = meta["aired"] if meta.get("last_aired") else sum(s.get("episode_count") or 0 for s in meta.get("seasons") or [])
    done = len([key for key in shown if key[0] > 0])
    if total:
        left = max(0, total - done)
        item.setProperty("lucent.left", T("Alles gezien", "All seen") if not left else
                         T("Nog 1 aflevering", "1 episode to go") if left == 1 else T("Nog %d afleveringen", "%d episodes to go") % left)
        item.setProperty("lucent.percent", str(min(100, int(100 * done / total))))
    season = max(shown, key=lambda key: (shown[key] or "", key))[0]
    in_season = tmdb.aired_in_season(meta, season) if meta.get("last_aired") else \
        next((s.get("episode_count") or 0 for s in meta.get("seasons") or [] if s.get("season_number") == season), 0)
    if in_season:
        seen_here = len([key for key in shown if key[0] == season])
        item.setProperty("lucent.progress", T("S%d · %d van %d", "S%d · %d of %d") % (season, min(seen_here, in_season), in_season))


def _action(label, url, icon="DefaultAddonProgram.png"):
    """A row that does something instead of opening a list."""
    item = xbmcgui.ListItem(label, offscreen=True)
    item.setArt({"icon": icon, "thumb": icon})
    item.setProperty("IsPlayable", "false")
    items.menu_look(item, url)
    return url, item, False


def home(handle, _params):
    """Watching first, then browsing, then your own things, then the tools."""
    if not tmdb.key():                  # nothing to browse yet: only the way to get started
        send(handle, [_action(T("Installatie-assistent: sleutels instellen", "Setup assistant: set your keys"), util.url_for(action="setup")),
                      _action(T("Profiel: %s", "Profile: %s") % users.current()["name"], util.url_for(action="who"), "DefaultUser.png"),
                      items.folder(T("Instellingen en hulp", "Settings and help"), util.url_for(action="tools"), "DefaultAddonProgram.png")])
        return
    rows = [
        items.folder(T("Films", "Movies"), util.url_for(action="menu", type="movie"), "DefaultMovies.png"),
        items.folder(T("Series", "Shows"), util.url_for(action="menu", type="tvshow"), "DefaultTVShows.png"),
        items.folder(T("Kompas", "Kompas"), util.url_for(action="kompasmenu"), "DefaultAddonsRecentlyUpdated.png"),
        _action(T("Wat zullen we kijken?", "What shall we watch?"), util.url_for(action="pick"), "DefaultAddonsRecentlyUpdated.png"),
        items.folder(T("Streamingdiensten", "Streaming services"), util.url_for(action="services"), "DefaultNetwork.png"),
        items.folder(T("Mijn lijsten", "My lists"), util.url_for(action="traktmenu"), "DefaultPlaylist.png"),
        items.folder(T("Zoeken", "Search"), util.url_for(action="searchmenu"), "DefaultAddonsSearch.png"),
        _action(T("Profiel: %s", "Profile: %s") % users.current()["name"], util.url_for(action="who"), "DefaultUser.png"),
        items.folder(T("Instellingen en hulp", "Settings and help"), util.url_for(action="tools"), "DefaultAddonProgram.png"),
    ]
    send(handle, rows)


def kompas_menu(handle, _params):
    """Kompas: the page, its rows (each can go on Home with 'Add to Home') and your taste."""
    import kompas
    if not kompas.on():
        return send(handle, [items.folder(T("Voor jou", "For you"), util.url_for(action="list", name="foryou"), "DefaultRecentlyAddedMovies.png")])
    data = util.load_json(kompas.ROWS, {})
    because = data.get("because")
    rows = [_action(T("Kompas: kies wat je wilt kijken", "Kompas: choose what to watch"), util.url_for(action="kompas_page"), "DefaultAddonsRecentlyUpdated.png"),
            items.folder(T("Voor jou gekozen", "Picked for you"), util.url_for(action="list", name="kompas_foryou"), "DefaultRecentlyAddedMovies.png")]
    if because:
        rows.append(items.folder(T("Omdat je %s keek", "Because you watched %s") % because, util.url_for(action="list", name="kompas_because"), "DefaultRecentlyAddedMovies.png"))
    rows += [items.folder(T("Verborgen parels", "Hidden gems"), util.url_for(action="list", name="kompas_gems"), "DefaultRecentlyAddedMovies.png"),
             items.folder(T("Nieuw voor jou", "New for you"), util.url_for(action="list", name="kompas_new"), "DefaultRecentlyAddedMovies.png"),
             items.folder(T("Trending voor jou", "Trending for you"), util.url_for(action="list", name="kompas_trending"), "DefaultRecentlyAddedMovies.png")]
    for saved in kompas.saved_rows():
        url, item, folder = items.folder(saved["label"], util.url_for(action="list", name="kompas_saved", id=saved["id"]), "DefaultPlaylist.png")
        item.addContextMenuItems([(T("Deze rij verwijderen", "Remove this row"), "RunPlugin(%s)" % util.url_for(action="kompas_unsave", id=saved["id"]))])
        rows.append((url, item, folder))
    rows.append(_action(T("Jouw smaak", "Your taste"), util.url_for(action="kompas_taste"), "DefaultUser.png"))
    send(handle, rows)


def menu(handle, params):
    movie = params.get("type") == "movie"
    if movie:
        entries = [(T("Trending", "Trending"), "trending_movie"), (T("Populair", "Popular"), "popular_movie"),
                   (T("Best beoordeeld", "Top rated"), "toprated_movie"), (T("Nu in de bioscoop", "In cinemas"), "nowplaying_movie"),
                   (T("Binnenkort", "Coming soon"), "upcoming_movie")]
    else:
        entries = [(T("Trending", "Trending"), "trending_tv"), (T("Populair", "Popular"), "popular_tv"),
                   (T("Nieuwe series", "New series"), "new_tv"),
                   (T("Best beoordeeld", "Top rated"), "toprated_tv"), (T("Vandaag op tv", "Airing today"), "today_tv"),
                   (T("Lopende series", "On the air"), "airing_tv"),
                   (T("Binnenkort", "Coming soon"), "upcoming_tv"), (T("Kalender: nieuwe afleveringen", "Calendar: new episodes"), "calendar"),
                   (T("Nieuwe seizoenen aangekondigd", "New seasons announced"), "new_seasons"),
                   (T("Op tijd voor het nieuwe seizoen", "In time for the new season"), "marathon")]
    # what you are watching first: films half watched, or series you stopped halfway and their next episode
    if movie:
        rows = [items.folder(T("Verder kijken", "Continue watching"), util.url_for(action="list", name="continue_movie"), "DefaultInProgressShows.png")]
    else:
        rows = [items.folder(T("Verder kijken en volgende aflevering", "Continue and next episode"), util.url_for(action="list", name="watching"),
                             "DefaultInProgressShows.png")]
    rows += [items.folder(label, util.url_for(action="list", name=name)) for label, name in entries]
    rows.append(items.folder(T("Genres", "Genres"), util.url_for(action="genres", type=params.get("type"))))
    rows.append(items.folder(T("Studio's", "Studios") if movie else T("Netwerken", "Networks"), util.url_for(action="studios", type=params.get("type"))))
    if movie:                                   # the same networks as for series (Netflix, HBO, Prime Video ...): their films
        rows.append(items.folder(T("Netwerken", "Networks"), util.url_for(action="studios", type="movie", networks="1")))
    else:                                       # TV studios (Warner Bros. Television, HBO, BBC Studios ...): their series
        rows.append(items.folder(T("Studio's", "Studios"), util.url_for(action="studios", type="tvshow", studios="1")))
    import discover
    if movie:
        season = discover.season_now()
        if season:                              # Christmas films from mid November, Halloween in October ...
            rows.insert(1, items.folder(discover.label(season), util.url_for(action="list", name="discover", key=season)))
        rows.append(items.folder(discover.label("digital"), util.url_for(action="list", name="discover", key="digital")))
        rows.append(items.folder(T("Filmreeksen", "Film series"), util.url_for(action="collections")))
    else:
        rows.append(items.folder(discover.label("ended"), util.url_for(action="list", name="discover", key="ended")))
    rows.append(items.folder(T("Meest verwacht", "Most anticipated"), util.url_for(action="list", name="anticipated", type=params.get("type"))))
    if movie:
        rows.append(items.folder(discover.label("short"), util.url_for(action="list", name="discover", key="short")))
        rows.append(items.folder(discover.label("long"), util.url_for(action="list", name="discover", key="long")))
    rows.append(items.folder(T("Per land", "By country"), util.url_for(action="countries", type="movie" if movie else "tvshow")))
    rows.append(items.folder(discover.label("anime_movie" if movie else "anime_tv"),
                             util.url_for(action="list", name="discover", key="anime_movie" if movie else "anime_tv")))
    rows.append(items.folder(T("Per decennium", "By decade"), util.url_for(action="decades", type=params.get("type"))))
    rows.append(items.folder(T("Populaire acteurs", "Popular people"), util.url_for(action="people")))
    rows.append(items.folder(T("Prijswinnaars", "Award winners"), util.url_for(action="awards", type=params.get("type"))))
    rows.append(items.folder(T("Films zoeken", "Search movies") if movie else T("Series zoeken", "Search shows"),
                             util.url_for(action="search", type="movie" if movie else "tvshow"), "DefaultAddonsSearch.png"))
    send(handle, rows)


def trakt_menu(handle, _params):
    """Everything that is yours: watchlists, collection and lists of every service you use."""
    import prefetch
    entries = [(T("Klaar voor vanavond", "Ready for tonight"), "tonight")] if prefetch.tonight() else []
    entries += [(T("Komt binnenkort uit", "Coming soon"), "coming_watchlist"), (T("Kijklijst films", "Watchlist movies"), "watchlist_movie"), (T("Kijklijst series", "Watchlist shows"), "watchlist_tv")]
    if tracker.logged_in() and tracker.name() not in ("PunchPlay", "MDBList"):        # PunchPlay, MDBList: no collection in Lucent
        entries += [(T("Collectie films", "Collection movies"), "collection_movie"), (T("Collectie series", "Collection shows"), "collection_tv")]
    rows = [items.folder(label, util.url_for(action="list", name=name)) for label, name in entries]
    if tracker.has_lists():
        rows.append(items.folder(T("Mijn eigen lijsten", "My own lists"), util.url_for(action="traktlists", kind="mine")))
        if tracker.name() == "Trakt":
            rows.append(items.folder(T("Lijsten die je leuk vindt", "Liked lists"), util.url_for(action="traktlists", kind="liked")))
            rows.append(items.folder(T("Openbare lijsten", "Public lists"), util.url_for(action="publiclists")))
    import tmdbacct
    if tmdbacct.linked():
        rows.append(items.folder("TMDB", util.url_for(action="tmdbmenu")))
    if mdblist.available():
        rows.append(items.folder("MDBList", util.url_for(action="mdblistmenu")))
    if floppy.available():
        rows.append(items.folder("Floppy", util.url_for(action="floppylists")))
    send(handle, rows)


def studios(handle, params):
    import browse
    kind = params.get("type", "movie")
    networks = params.get("networks") == "1" and kind == "movie"
    studios = params.get("studios") == "1" and kind == "tvshow"
    rows = []
    found = browse.tv_studios() if studios else browse.companies("tvshow" if networks else kind)
    import logos                                # TMDB's sharp logos, the black ones made white; else the shipped ones
    import services
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=8) as pool:
        sharp = list(pool.map(lambda row: logos.readable(row[2]), found))
    found = [(number, name, logo or services.coloured_logo(name)) for (number, name, _old), logo in zip(found, sharp)]
    for number, name, logo in found:
        if networks and not browse.network_provider(name):
            continue                            # a TV channel (ABC, BBC One ...): no films to stream
        if networks:                            # a network's films: what it streams (TMDB has no network for films)
            url, item, folder = items.folder(name, util.url_for(action="list", name="network_films", network=name))
        elif studios:                           # a TV studio's series: TMDB's production companies
            url, item, folder = items.folder(name, util.url_for(action="list", name="studio_series", id=number))
        else:
            url, item, folder = items.folder(name, util.url_for(action="list", name="company", type=kind, id=number))
        if logo:
            item.setArt({"icon": logo, "thumb": logo, "clearlogo": logo})
        rows.append((url, item, folder))
    send(handle, rows)


def collections(handle, _params):
    """Film series (TMDB collections): Harry Potter, Star Wars, Mission: Impossible ... in the order they came out."""
    import discover
    rows = []
    for number, name, poster in discover.collections():
        url, item, folder = items.folder(name, util.url_for(action="list", name="collection", id=number))
        if poster:
            item.setArt({"poster": poster, "thumb": poster, "icon": poster})
        rows.append((url, item, folder))
    send(handle, rows)


def countries(handle, params):
    import discover
    kind = "movie" if params.get("type") == "movie" else "tvshow"
    send(handle, [items.folder(discover.label(key), util.url_for(action="list", name="discover", key=key))
                  for key in discover.COUNTRIES[kind]])


def decades(handle, params):
    import browse
    kind = params.get("type", "movie")
    send(handle, [items.folder(T("Jaren '%02d", "%ds") % (start % 100) if start < 2000 else "%ds" % start,
                               util.url_for(action="list", name="decade", type=kind, start=start)) for start in browse.DECADES])


def awards(handle, params):
    import browse
    kind = params.get("type", "movie")
    send(handle, [items.folder(label, util.url_for(action="list", name="award", key=key))
                  for key, (label, what, _w) in browse.AWARDS.items() if what == kind])


def tools(handle, _params):
    rows = [
        _action(T("Instellingen openen", "Open settings"), util.url_for(action="settings")),
        _action(T("Installatie-assistent", "Setup assistant"), util.url_for(action="setup")),
        _action(T("Ondertitels en geluid instellen", "Set up subtitles and sound"), util.url_for(action="subs_setup")),
        _action(T("Intro overslaan instellen", "Set up skip intro"), util.url_for(action="skip_setup")),
        _action(T("Volgorde van bronnen", "Order of sources"), util.url_for(action="ranking")),
        _action(T("Bibliotheek nu bijwerken", "Update the library now"), util.url_for(action="library_sync"), "DefaultAddonLibrary.png"),
        _action(T("Kiezen wat in de bibliotheek komt", "Choose what goes in the library"), util.url_for(action="library_choose"), "DefaultAddonLibrary.png"),
        _action(T("Je kijkjaar", "Your year of watching"), util.url_for(action="year")),
        _action(T("Back-up maken of terugzetten", "Backup and restore"), util.url_for(action="backup")),
        _action(T("Foutrapport maken", "Make an error report"), util.url_for(action="report")),
        _action(T("Cache wissen", "Clear cache"), util.url_for(action="clear_cache")),
    ]
    send(handle, rows)


def _query(params):
    return params.get("query") or xbmcgui.Dialog().input(T("Lijst zoeken", "Search lists"))


def trakt_lists(handle, params):
    kind = params.get("kind")
    query = None
    if kind == "search":
        query = _query(params)
        if not query:
            return xbmcplugin.endOfDirectory(handle, succeeded=False)
    rows = [items.folder(name, util.url_for(action="list", name="traktlist", user=owner, id=list_id))
            for owner, list_id, name in tracker.custom_lists(kind, query)]
    send(handle, rows)
    return None


def public_lists(handle, _params):
    send(handle, [items.folder(label, util.url_for(action="traktlists", kind=kind)) for label, kind in
                  ((T("Trending lijsten", "Trending lists"), "trending"), (T("Populaire lijsten", "Popular lists"), "popular"), (T("Lijst zoeken", "Search lists"), "search"))])


def floppy_lists(handle, _params):
    send(handle, [items.folder(name, util.url_for(action="list", name="floppylist", id=list_id)) for list_id, name in floppy.lists()])


def mdblist_menu(handle, _params):
    send(handle, [items.folder(label, util.url_for(action="mdblists", kind=kind)) for label, kind in
                  ((T("Mijn lijsten", "My lists"), "mine"), (T("Lijsten die je leuk vindt", "Liked lists"), "liked"), (T("Toplijsten", "Top lists"), "top"), (T("Lijst zoeken", "Search lists"), "search"))])


def mdblists(handle, params):
    kind = params.get("kind", "mine")
    query = None
    if kind == "search":
        query = _query(params)
        if not query:
            return xbmcplugin.endOfDirectory(handle, succeeded=False)
    send(handle, [items.folder(name, util.url_for(action="list", name="mdblist", id=list_id)) for list_id, name in mdblist.lists(kind, query)])
    return None


def genres(handle, params):
    api = "movie" if params.get("type") == "movie" else "tv"
    rows = [items.folder(g["name"], util.url_for(action="list", name="genre", type=params.get("type"), genre=g["id"]))
            for g in tmdb.get("genre/%s/list" % api, ttl=7 * tmdb.DAY).get("genres") or []]
    send(handle, rows)


def services(handle, params):
    rows = []
    only = {"type": params["type"]} if params.get("type") in ("movie", "tvshow") else {}
    for provider, name, logo in tmdb.providers():
        url, item, folder = items.folder(name, util.url_for(action="service", provider=provider, name=name, **only))
        item.setArt({"icon": logo, "thumb": logo, "poster": logo})
        rows.append((url, item, folder))
    send(handle, rows)


def service(handle, params):
    """One streaming service: newest first, then new, popular and top rated (only films when you came from Films)."""
    import services
    only = params.get("type")
    rows = [items.folder(T("Nieuwste eerst", "Newest first"), util.url_for(action="list", name="provider", provider=params["provider"],
                                                                         type=only if only in ("movie", "tvshow") else "all"))]
    rows += [items.folder(services.label(kind), util.url_for(action="list", name="service_list", provider=params["provider"], kind=kind))
             for kind in services.KINDS if only not in ("movie", "tvshow") or services.KINDS[kind][1] == only]
    send(handle, rows)


HISTORY = "search_history.json"


def search_menu(handle, _params):
    rows = [items.folder(T("Films zoeken", "Search movies"), util.url_for(action="search", type="movie"), "DefaultAddonsSearch.png"),
            items.folder(T("Series zoeken", "Search shows"), util.url_for(action="search", type="tvshow"), "DefaultAddonsSearch.png"),
            _action(T("Typ met je telefoon", "Type with your phone"), util.url_for(action="remote"), "DefaultAddonsSearch.png")]
    if util.setting("easynews_user") and util.setting("easynews_pass"):
        rows.append(items.folder(T("Zoeken op Easynews", "Search Easynews"), util.url_for(action="easynews_search"), "DefaultAddonsSearch.png"))
    history = util.load_json(HISTORY, [])
    for kind, query in history:
        word = T("Film", "Movie") if kind == "movie" else T("Serie", "Show")
        rows.append(items.folder("%s: %s" % (word, query), util.url_for(action="search", type=kind, query=query), "DefaultAddonsSearch.png"))
    if history:
        rows.append((util.url_for(action="clear_history"), xbmcgui.ListItem(T("Zoekgeschiedenis wissen", "Clear search history"), offscreen=True), False))
    send(handle, rows)


EN_HISTORY = "easynews_history.json"


def easynews_search(handle, params):
    """Easynews searched for your own words: for files that do not match a title (WALL·E, a concert, a documentary).
    Without words: a new search and the earlier ones."""
    query = params.get("query")
    if not query and not params.get("new"):
        history = util.load_json(EN_HISTORY, [])
        if history:
            rows = [_action(T("Nieuwe zoekopdracht", "New search"), util.url_for(action="easynews_search", new="1"), "DefaultAddonsSearch.png")]
            rows += [items.folder(word, util.url_for(action="easynews_search", query=word), "DefaultAddonsSearch.png") for word in history]
            rows.append((util.url_for(action="clear_history", which="easynews"), xbmcgui.ListItem(T("Zoekgeschiedenis wissen", "Clear search history"), offscreen=True), False))
            return send(handle, rows)
    if not query:
        query = xbmcgui.Dialog().input(T("Zoeken op Easynews", "Search Easynews"))
        if not query:
            return xbmcplugin.endOfDirectory(handle, succeeded=False)
        query = query.strip()
        history = [q for q in util.load_json(EN_HISTORY, []) if q != query]
        util.save_json(EN_HISTORY, ([query] + history)[:20])
    try:
        found = usenet.free_sources(query)
    except util.HttpError as error:
        util.notify(T("Easynews: %s", "Easynews: %s") % error)
        return xbmcplugin.endOfDirectory(handle, succeeded=False)
    rows = []
    for source in found:
        url = util.url_for(action="easynews_play", base=source["base"], path=source["path"], name=source["name"])
        item = xbmcgui.ListItem(source["name"], "%s · %s" % (source["resolution"], source["meta"]), offscreen=True)
        item.setInfo("video", {"title": source["name"], "plot": "%s · %s" % (source["resolution"], source["meta"])})
        item.setProperty("IsPlayable", "true")
        if source.get("preview"):
            item.setArt({"thumb": source["preview"]})
            item.addContextMenuItems([(T("Voorvertoning", "Preview"), "RunPlugin(%s)" % util.url_for(action="easynews_preview", url=source["preview"], name=source["name"]))])
        rows.append((url, item, False))
    if not rows:
        util.notify(T("Niets gevonden op Easynews", "Nothing found on Easynews"))
    return send(handle, rows, "videos")


def easynews_play(handle, params):
    url = usenet.direct(usenet.play_url(params["base"], params["path"]))
    item = xbmcgui.ListItem(params.get("name") or "", path=url, offscreen=True)
    util.log("playing an Easynews file found with your own words")
    xbmcplugin.setResolvedUrl(handle, True, item)


def easynews_pictures(handle, params):
    """Easynews' photos of a person (picture groups, safe filter on), like Fen shows them."""
    try:
        found = usenet.pictures(params["name"])
    except util.HttpError as error:
        util.notify(T("Easynews: %s", "Easynews: %s") % error)
        return xbmcplugin.endOfDirectory(handle, succeeded=False)
    rows = []
    for number, (small, large) in enumerate(found, 1):
        item = xbmcgui.ListItem("%s %d" % (params["name"], number), offscreen=True)
        item.setArt({"thumb": small, "icon": small})
        rows.append((large, item, False))
    if not rows:
        util.notify(T("Geen foto's gevonden op Easynews", "No photos found on Easynews"))
    return send(handle, rows, "images")


def remember_search(kind, query):
    history = [entry for entry in util.load_json(HISTORY, []) if entry != [kind, query]]
    util.save_json(HISTORY, ([[kind, query]] + history)[:15])


ARTICLES = ("the ", "a ", "an ", "de ", "het ", "een ")


def _alphabetical(meta):
    title = (meta.get("title") or "").casefold().strip()
    for article in ARTICLES:
        if title.startswith(article):
            title = title[len(article):]
            break
    return title, meta.get("year") or 0


def _slice(pairs, page):
    start = (page - 1) * PAGE
    return pairs[start:start + PAGE], len(pairs) > start + PAGE


def continue_titles(only=None):
    titles = []
    def load(row):
        try:
            if row.get("type") == "movie":
                meta = tmdb.details("movie", row["movie"]["ids"]["tmdb"])
            else:
                meta = player.title_meta("episode", row["show"]["ids"]["tmdb"], row["episode"]["season"], row["episode"]["number"])
        except (util.HttpError, KeyError, TypeError):
            return None
        if meta:
            meta["resume_percent"] = row.get("progress") or 0
        return meta
    with ThreadPoolExecutor(max_workers=6) as pool:
        titles = [m for m in pool.map(load, [r for r in tracker.paused() if not only or r.get("type") == only][:40]) if m]
    return titles


def next_up_titles():
    cached = util.cache_get("nextup", 300)
    if cached is not None:
        return cached

    def load(entry):
        try:
            return player.title_meta("episode", entry[0], int(entry[1]), int(entry[2]))
        except (util.HttpError, KeyError, TypeError):
            return None
    with ThreadPoolExecutor(max_workers=6) as pool:
        titles = [m for m in pool.map(load, tracker.next_up()) if m and tmdb.aired(m.get("premiered"))]
    util.cache_set("nextup", titles)
    return titles


def watching_titles():
    """'Continue watching' and 'Next up' for series in one row: episodes you stopped halfway and the next unseen
    episode of each series you watch, newest first over both, one item per series. Films are not in it: they have
    their own row (continue_movie)."""
    def stamp(text):
        return str(text or "").replace("T", " ")[:19]

    def when(row):                                  # Trakt / Simkl: paused_at; this device: 'at' (seconds)
        if row.get("paused_at"):
            return stamp(row["paused_at"])
        return time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(row.get("at") or 0)) if row.get("at") else ""

    try:
        resumes = [r for r in tracker.paused() if r.get("type") == "episode"]
    except util.HttpError:
        resumes = []
    try:
        following = tracker.next_up()
    except util.HttpError:
        following = []
    try:
        seen = tracker.watched_episodes()
    except util.HttpError:
        seen = {}
    rows, shows = [], set()
    for row in sorted(resumes, key=when, reverse=True):
        try:
            show = str(row["show"]["ids"]["tmdb"])
            if show in shows:
                continue                                   # one item per series: the newest
            shows.add(show)
            rows.append((when(row), ("episode", show, row["episode"]["season"], row["episode"]["number"]), row.get("progress") or 0))
        except (KeyError, TypeError):
            continue
    for show, season, episode in following:
        if str(show) in shows:
            continue
        shows.add(str(show))
        last = max((seen.get(str(show)) or {}).values() or [""])
        rows.append((stamp(last), ("episode", str(show), int(season), int(episode)), 0))
    rows.sort(key=lambda r: r[0], reverse=True)

    def load(row):
        _when, (kind, tmdb_id, season, episode), progress = row
        try:
            meta = tmdb.details("movie", tmdb_id) if kind == "movie" else player.title_meta("episode", tmdb_id, season, episode)
        except (util.HttpError, KeyError, TypeError):
            return None
        if not meta or (kind == "episode" and not progress and not tmdb.aired(meta.get("premiered"))):
            return None
        if progress:
            meta["resume_percent"] = progress
        return meta
    with ThreadPoolExecutor(max_workers=6) as pool:
        loaded = [(row, m) for row, m in zip(rows[:40], pool.map(load, rows[:40])) if m]
    # first the new episodes (out in the last 30 days and after you last watched that series), newest first;
    # then everything else as before: what you watched or stopped most recently first
    recent = (datetime.date.today() - datetime.timedelta(days=NEW_DAYS)).isoformat()

    def is_new(row, meta):
        aired = str(meta.get("premiered") or "")[:10]
        return not row[2] and aired >= recent and aired > str(row[0])[:10]
    new = sorted([m for row, m in loaded if is_new(row, m)], key=lambda m: str(m.get("premiered") or ""), reverse=True)
    return new + [m for row, m in loaded if not is_new(row, m)]


NEW_DAYS = 30


def calendar_titles():
    """Episodes still to come of what you follow, from today up to two months ahead, the first one first."""
    today = datetime.date.today()
    first, last = today.isoformat(), (today + datetime.timedelta(days=60)).isoformat()

    def load(show):
        try:
            _aired, coming = tmdb.on_air(show)
            if not coming:
                return []
            episodes = tmdb.season(show, coming["season_number"]).get("episodes") or [coming]
            found = []
            for episode in episodes:
                if first <= (episode.get("air_date") or "") <= last:
                    meta = player.title_meta("episode", show, episode["season_number"], episode["episode_number"])
                    if meta:
                        found.append(meta)
            return found
        except (util.HttpError, KeyError, TypeError):
            return []
    shows = list(tracker.watched_episodes())[:60] + [str(i) for _k, i in tracker.pairs("watchlist_tv")][:40]
    with ThreadPoolExecutor(max_workers=6) as pool:
        titles = [meta for found in pool.map(load, list(dict.fromkeys(shows))) for meta in found]
    return sorted(titles, key=lambda m: m.get("premiered") or "")


def for_you_titles():
    """Recommendations from what you watched last, without what you already saw."""
    films, shows = tracker.watched_movies(), tracker.watched_episodes()
    recent_films = sorted(films, key=lambda i: films[i], reverse=True)[:6]
    recent_shows = sorted(shows, key=lambda i: max(shows[i].values()) if shows[i] else "", reverse=True)[:6]

    def load(job):
        api, kind, tmdb_id = job
        try:
            return [(kind, r["id"]) for r in tmdb.get("%s/%s/recommendations" % (api, tmdb_id), ttl=tmdb.DAY).get("results") or []]
        except util.HttpError:
            return []
    jobs = [("movie", "movie", i) for i in recent_films] + [("tv", "tvshow", i) for i in recent_shows]
    with ThreadPoolExecutor(max_workers=6) as pool:
        results = list(pool.map(load, jobs))
    counts = {}
    for found in results:
        for pair in found:
            counts[pair] = counts.get(pair, 0) + 1
    fresh = [p for p in counts if not (p[0] == "movie" and str(p[1]) in films) and not (p[0] == "tvshow" and str(p[1]) in shows)]
    fresh.sort(key=lambda p: counts[p], reverse=True)
    return tmdb.many(fresh[:40])


def _timezone():
    """Your time zone for 'Airing today' (TMDB counts the day in New York otherwise)."""
    try:
        import time as _time
        offset = -_time.altzone if _time.daylight and _time.localtime().tm_isdst else -_time.timezone
    except (AttributeError, ValueError):
        offset = 0
    return "Europe/Amsterdam" if util.NL else ("UTC" if not offset else "Etc/GMT%+d" % (-offset // 3600))


def people(handle, params):
    """Popular actors and actresses right now: OK opens their films and series."""
    import tmdbextra
    page = int(params.get("page") or 1)
    found, more = tmdbextra.popular_people(page)
    rows = []
    for person_id, name, portrait, known in found:
        url, item, folder = items.folder(name, util.url_for(action="list", name="person", id=person_id))
        item.setLabel2(known)
        if portrait:
            item.setArt({"thumb": portrait, "poster": portrait, "icon": portrait})
        rows.append((url, item, folder))
    send(handle, rows, more=util.url_for(action="people", page=page + 1) if more else None)


def tmdb_menu(handle, _params):
    """Your TMDB account: watchlists, favourites and ratings."""
    import tmdbacct
    rows = [items.folder(tmdbacct.LABELS[name], util.url_for(action="list", name=name)) for name in tmdbacct.LISTS]
    send(handle, rows)


def cast(handle, params):
    meta = tmdb.details(params.get("type", "movie"), params["tmdb"])
    people = (meta or {}).get("cast") or []
    if params.get("type", "movie") != "movie":
        people = tmdb.series_cast(params["tmdb"]) or people                     # every season, not only the latest
    rows = []
    for person in people:
        url, item, folder = items.folder(person["name"], util.url_for(action="list", name="person", id=person.get("id")))
        item.setLabel2(person.get("role") or "")
        if person.get("thumb"):
            item.setArt({"thumb": person["thumb"], "poster": person["thumb"], "icon": person["thumb"]})
        rows.append((url, item, folder))
    send(handle, rows)


def list_titles(handle, params):
    """A list of titles. A row on Home (&widget=1) is served from its saved copy at once and refreshed after."""
    import widgets
    name = params.get("name", "")
    if name == "service_row":
        import services
        return send(handle, services.tiles())
    if name == "service_catalog":
        import services
        return send(handle, services.catalog_tiles())
    if name in ("lib_newseasons", "lib_newepisodes"):
        import librows
        return librows.send_row(handle, name)
    page = int(params.get("page") or 1)
    import hide
    size = util.number("widget_size", 20) if params.get("widget") == "1" else 0       # a Home row: as many as you chose
    cut = (lambda rows: rows[:size]) if size else (lambda rows: rows)
    began = time.time()
    cached = widgets.get(params) if widgets.wanted(params) else None
    if cached:
        send_titles(handle, cut(hide.keep(cached.get("titles") or [], name)), cached.get("content") or "")
        if params.get("widget") == "1":
            _row_time(name, "copy", began)
        if widgets.is_old(params, cached, size):
            try:
                titles, content, _more = gather_row(params, size)
            except Exception as error:      # noqa: BLE001 - the copy stays; try again next time
                util.log("row %s not refreshed: %s" % (name, type(error).__name__))
                return None
            tracker.enrich(titles)          # the copy keeps the scores, so showing it never looks them up
            changed = not widgets.same(cached, titles, content)
            yours = widgets.emptied_by_you(params, cached)
            if titles or not cached.get("titles") or yours:
                widgets.put(params, titles, content, size)
            if changed and (titles or yours):
                widgets.bump()
        return None
    try:
        titles, content, more = gather_row(params, size)
    except Exception as error:              # noqa: BLE001 - the saved copy of this row is better than an empty folder
        saved = widgets.get(params)
        if not saved or not saved.get("titles"):
            raise
        util.log("list %s: %s, its saved copy shown" % (name, type(error).__name__))
        return send_titles(handle, hide.keep(saved["titles"], name), saved.get("content") or "")
    TIMES["fetch"] = time.time() - began
    if widgets.wanted(params) and titles:
        tracker.enrich(titles)              # before the copy is saved: then the copy has the scores too
        widgets.put(params, titles, content, size)
    next_url = util.url_for(**dict(params, page=page + 1)) if more and params.get("widget") != "1" else None     # a Home row has no next page
    send_titles(handle, cut(hide.keep(titles, name)), content, next_url)
    if params.get("widget") == "1":
        _row_time(name, "fetched", began)
    return None


def gather_row(params, size):
    """A list, with more pages fetched for a Home row until it holds the number of titles you chose (at most 6 pages)."""
    titles, content, more = gather(params)
    if not size:
        return titles, content, more
    import hide
    name, page = params.get("name", ""), int(params.get("page") or 1)
    seen = {(t.get("kind"), str(t.get("tmdb")), t.get("season"), t.get("episode")) for t in titles}
    while more and len(hide.keep(titles, name)) < size and page < 6:
        page += 1
        extra, _content, more = gather(dict(params, page=page))
        for meta in extra:
            key = (meta.get("kind"), str(meta.get("tmdb")), meta.get("season"), meta.get("episode"))
            if key not in seen:
                seen.add(key)
                titles.append(meta)
    return titles, content, more


def gather(params):
    """(titles, content, more pages?) of one list."""
    name = params.get("name", "")
    page = int(params.get("page") or 1)
    more = False
    content = "movies"
    if name in TMDB_LISTS:
        path, kind = TMDB_LISTS[name]
        titles, more = tmdb.listing(path, kind, page)
    elif name == "genre":
        kind = params.get("type")
        titles, more = tmdb.listing("discover/" + ("movie" if kind == "movie" else "tv"), kind, page,
                                    with_genres=params["genre"], sort_by="popularity.desc")
    elif name == "new_seasons":
        import newseason
        titles, content = newseason.titles(), "tvshows"
    elif name == "marathon":
        import marathon
        titles, content = marathon.titles(), "tvshows"
    elif name == "coming_watchlist":
        import coming
        titles = coming.titles()
    elif name == "tonight":
        import prefetch
        titles = prefetch.tonight_titles()
    elif name == "discover":
        import discover
        titles, more = discover.titles(params["key"], page)
        kind = discover.PRESETS[params["key"]][1] if params["key"] in discover.PRESETS else "movie"
        content = "movies" if kind == "movie" else "tvshows"
    elif name == "anticipated":
        import discover
        kind = "movie" if params.get("type") == "movie" else "tvshow"
        titles, more = discover.anticipated(kind, page)
        content = "movies" if kind == "movie" else "tvshows"
    elif name == "collection":
        import discover
        titles, content = discover.collection_titles(params["id"]), "movies"
    elif name == "studio_series":
        import browse
        titles, more = browse.studio_series(params["id"], page)
        content = "tvshows"
    elif name == "network_films":
        import browse
        titles, more = browse.network_films(params["network"], page)
        content = "movies"
    elif name == "company":
        import browse
        titles, more = browse.company_titles(params.get("type", "movie"), params["id"], page)
        content = "movies" if params.get("type") == "movie" else "tvshows"
    elif name == "decade":
        import browse
        titles, more = browse.decade_titles(params.get("type", "movie"), params["start"], page)
        content = "movies" if params.get("type") == "movie" else "tvshows"
    elif name == "award":
        import browse
        titles, more = browse.award_titles(params["key"], page)
        content = "movies" if browse.AWARDS[params["key"]][1] == "movie" else "tvshows"
    elif name == "alerts":
        import alerts
        titles = alerts.titles()
    elif name.startswith("kompas"):
        import kompas
        titles = kompas.row_titles(name, params)
    elif name == "service_list":
        import services
        titles, more = services.titles(params["provider"], params.get("kind", "newmovie"), page)
        content = "movies" if params.get("kind", "").endswith("movie") else "tvshows"
    elif name == "today_tv":
        titles, more = tmdb.listing("tv/airing_today", "tvshow", page, timezone=_timezone())
        content = "tvshows"
    elif name == "keyword":
        import tmdbextra
        kind = "movie" if params.get("type") == "movie" else "tvshow"
        titles, more = tmdbextra.keyword_titles(kind, params["tmdb"], page)
        content = "movies" if kind == "movie" else "tvshows"
    elif name.startswith("tmdb_"):                # your TMDB account (tmdbacct.LISTS)
        import tmdbacct
        titles, more = tmdbacct.titles(name, page)
        content = "movies" if name.endswith("_movie") else "tvshows"
    elif name == "new_tv":
        titles, more = tmdb.new_series(page)
        content = "tvshows"
    elif name in ("upcoming_movie", "upcoming_tv"):
        kind = "movie" if name == "upcoming_movie" else "tvshow"
        titles, more = tmdb.upcoming(kind, page)
        content = "movies" if kind == "movie" else "tvshows"
    elif name == "calendar":
        titles, content = calendar_titles(), "episodes"
    elif name == "foryou":
        titles = for_you_titles()
    elif name == "person":
        titles = tmdb.many(tmdb.person_titles(params["id"]))
    elif name == "provider":
        titles, more = tmdb.newest_on(params["provider"], params.get("type", "all"), page)
    elif name == "similar":
        kind = "movie" if params.get("type") == "movie" else "tvshow"           # the skin sends type=tv, Lucent type=tvshow
        titles, more = tmdb.listing("%s/%s/recommendations" % ("movie" if kind == "movie" else "tv", params["tmdb"]), kind, page)
    elif name == "continue":
        titles = continue_titles()
    elif name == "continue_movie":
        titles = continue_titles("movie")
    elif name == "continue_episode":
        titles, content = continue_titles("episode"), "episodes"
    elif name == "nextup":
        titles, content = next_up_titles(), "episodes"
    elif name == "watching":
        titles = watching_titles()
    elif name in ("collection_movie", "collection_tv"):          # the whole collection, A to Z
        everything = sorted(tmdb.many(tracker.pairs(name)), key=_alphabetical)
        titles, more = _slice(everything, page)
        _date_added(titles, tracker.dates(name))
    elif name in ACCOUNT_LISTS:
        slice_of, more = _slice(tracker.pairs(name), page)
        titles = tmdb.many(slice_of)
        _date_added(titles, tracker.dates(name))
    elif name == "traktlist":
        found = tracker.list_pairs(params["user"], params["id"], page, PAGE)
        titles, more = tmdb.many(found), len(found) >= PAGE
        _date_added(titles, tracker.list_dates(params["user"], params["id"], page, PAGE))
    elif name == "floppylist":
        found, more = floppy.items(params["id"], page, PAGE)
        titles = tmdb.many(found)
    elif name == "mdblist":
        found, more = mdblist.items(params["id"], page, PAGE)
        titles = tmdb.many(found)
    else:
        titles = []
    if titles and all(t["kind"] == "tvshow" for t in titles):
        content = "tvshows"
    elif titles and all(t["kind"] == "episode" for t in titles):
        content = "episodes"
    return titles, content, more


def _date_added(titles, dates):
    """When each title was added to the list (watchlist, collection, a list), so 'Date added' sorting in the skin works."""
    if not dates:
        return
    by_id = {(kind, str(tmdb_id)): when for (kind, tmdb_id), when in dates.items()}
    for meta in titles:
        when = by_id.get((meta.get("kind"), str(meta.get("tmdb"))))
        if when:
            meta["dateadded"] = str(when).replace("T", " ")[:19]


def search(handle, params):
    query = params.get("query") or xbmcgui.Dialog().input(T("Zoeken", "Search"))
    if not query:
        return xbmcplugin.endOfDirectory(handle, succeeded=False)
    kind = params.get("type", "movie")
    page = int(params.get("page") or 1)
    if page == 1:
        remember_search(kind, query.strip())
    titles, more = tmdb.listing("search/" + ("movie" if kind == "movie" else "tv"), kind, page, query=query, include_adult="false")
    next_url = util.url_for(action="search", type=kind, query=query, page=page + 1) if more else None
    send_titles(handle, titles, "movies" if kind == "movie" else "tvshows", next_url)
    return None


def seasons(handle, params):
    show = tmdb.details("tvshow", params["tmdb"])
    titles = []
    for raw in (show or {}).get("seasons") or []:
        titles.append(dict(show, kind="season", show=show["title"], season=raw["season_number"],
                           title=raw.get("name") or "", plot=raw.get("overview") or show["plot"],
                           poster=tmdb.image(raw.get("poster_path"), "w500") or show["poster"],
                           premiered=raw.get("air_date") or "", episodes=raw.get("episode_count") or 0))
    shown = tracker.watched_episodes().get(params["tmdb"], {})
    rows = []
    for meta in titles:
        count = sum(1 for s, _e in shown if s == meta["season"])
        total = tmdb.aired_in_season(show, meta["season"]) if show.get("last_aired") else meta["episodes"]
        rows.append(items.title_item(meta, bool(total) and count >= total, counts=(total, count)))
    send(handle, rows, "seasons")


def episodes(handle, params):
    show = tmdb.details("tvshow", params["tmdb"])
    raw_list = tmdb.season(params["tmdb"], params["season"]).get("episodes") or []
    titles = [dict(tmdb.episode_meta(show, raw), season_count=len(raw_list)) for raw in raw_list if tmdb.aired(raw.get("air_date"))] if show else []
    send_titles(handle, titles, "episodes")


def _meta_for(params):
    return {"kind": params["type"], "tmdb": params["tmdb"], "season": params.get("season"), "episode": params.get("episode")}


def set_watched(params):
    """Also for titles from other add-ons (the skin's info page): any TMDB id, movie, tvshow, season or episode."""
    meta, watched = _meta_for(params), params.get("value") == "1"
    if meta["kind"] in ("tvshow", "season") and not tracker.active() and not tmdb.key():
        return util.notify(T("Zonder TMDB-sleutel weet Lucent niet welke afleveringen er zijn", "Without a TMDB key Lucent does not know the episodes"))
    try:
        tracker.set_watched(meta, watched)
    except util.HttpError as error:
        util.log("watched: %s" % error)
        return util.notify(T("Je account is niet bereikbaar, er is niets gewijzigd", "Your account cannot be reached, nothing was changed"))
    util.log("marked %s %s %s" % (meta["kind"], meta["tmdb"], "watched" if watched else "unwatched"))
    util.notify(T("Gemarkeerd als bekeken", "Marked as watched") if watched else T("Gemarkeerd als niet bekeken", "Marked as unwatched"))
    import widgets
    widgets.mark_old(account_only=True)
    xbmc.executebuiltin("Container.Refresh")


def _action_of(command):
    """The action=... of a RunPlugin/PlayMedia/Container.Update command, or ''."""
    import urllib.parse
    inner = command[command.find("(") + 1:-1]
    return dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(inner).query)).get("action", "")


def title_menu(params):
    """All of Lucent Video's options for one title, as one menu (for a '...' button on the skin's info page; works for
    titles from other add-ons too): choose source, ready for tonight, watched, intro, library and lists, trailer, cast,
    similar, rate."""
    meta = _meta_for(params)
    full = tmdb.details("movie" if meta["kind"] == "movie" else "tvshow", meta["tmdb"]) if tmdb.key() else None
    if full:
        meta = dict(full, kind=meta["kind"], season=meta.get("season"), episode=meta.get("episode"))
    meta.setdefault("title", "")
    if meta["kind"] == "movie":
        seen = meta["tmdb"] in tracker.watched_movies()
    elif meta["kind"] == "episode":
        seen = (int(meta["season"]), int(meta["episode"])) in tracker.watched_episodes().get(str(meta["tmdb"]), {})
    else:
        seen = False
    resumable = False
    if meta["kind"] in ("movie", "episode"):
        try:
            resumable = player.progress_key(meta) in util.load_json(player.LOCAL, {}) or bool(
                tracker.resume_percent(meta["kind"], meta["tmdb"], meta.get("season"), meta.get("episode")))
        except (util.HttpError, KeyError, TypeError, ValueError):
            resumable = False
    entries = items.context(meta, seen, resumable)
    if meta["kind"] in ("movie", "tvshow"):
        entries.insert(0, (T("Bibliotheek en lijsten", "Library and lists"), "RunPlugin(%s)" % util.url_for(action="lists", type=meta["kind"], tmdb=meta["tmdb"])))
        if params.get("all") != "1":
            # the info page already has buttons for these (Library and lists covers watchlist and library):
            # 'More' only shows what is not on the page yet
            on_page = {"lists", "watched", "watchlist", "trailer", "cast_popup", "library_add", "library_remove"}
            trailer = lambda command: command.startswith("PlayMedia(") and "select=1" not in command     # noqa: E731
            entries = [entry for entry in entries if _action_of(entry[1]) not in on_page and not trailer(entry[1])]
    picked = xbmcgui.Dialog().contextmenu([label for label, _command in entries])
    if picked >= 0:
        command = entries[picked][1]
        if command.startswith("Container.Update("):          # from a dialog: open the list in the Videos window
            command = "ActivateWindow(Videos,%s,return)" % command[len("Container.Update("):-1]
        xbmc.executebuiltin(command)


def forget_resume(params):
    """'Clear resume point' on a film or episode: forgotten on this device, on your account and in the Kodi library."""
    meta = _meta_for(params)
    try:
        tracker.forget_resume(meta)
    except util.HttpError as error:
        util.log("resume forget: %s" % error)
        return util.notify(T("Je account is niet bereikbaar, er is niets gewijzigd", "Your account cannot be reached, nothing was changed"))
    try:
        library.clear_resume(meta)
    except Exception as error:      # noqa: BLE001 - the library is a bonus here
        util.log("resume forget, library: %s" % type(error).__name__)
    try:
        library.clear_kodi_resume(meta)
    except Exception as error:      # noqa: BLE001
        util.log("resume forget, Kodi's own point: %s" % type(error).__name__)
    util.log("resume point of %s removed" % player.progress_key(meta))
    util.notify(T("Hervatpunt gewist: hij begint weer vooraan", "Resume point cleared: it starts from the beginning"))
    import widgets
    widgets.mark_old(account_only=True)
    xbmc.executebuiltin("Container.Refresh")


def set_watchlist(params):
    tracker.set_watchlist(_meta_for(params), params.get("value") == "1")
    import widgets
    widgets.mark_old(account_only=True)
    util.notify(T("Kijklijst bijgewerkt", "Watchlist updated"))


def title(handle, params):
    """One film or series by TMDB id, as a list of one: for the skin's info page."""
    kind = params.get("type", "movie")
    meta = tmdb.details(kind, params["tmdb"])
    send_titles(handle, [meta] if meta else [], "movies" if kind == "movie" else "tvshows")


SECTIONS = {"general": -100, "account": -99, "trakt": -99, "sources": -98, "conn": -98, "play": -97, "subs": -96, "skip": -95,
            "library": -94, "services": -93, "usenet": -92}
SUBTITLE_ACTIONS = ("subtitles", "subs_auto", "subs_background", "subs_prefetch", "subs_ready", "subs_earlier", "subs_later", "subs_other", "subs_key", "subs_mode", "subs_audio", "subs_default",
                    "subs_settings", "skip_settings", "subs_setup", "skip_setup", "skip_install", "skip_auto")


def _once(name, job):
    """Only one at a time (the service and Kodi's search can ask within seconds)."""
    if util.HOME.getProperty(name):
        return None
    util.HOME.setProperty(name, "1")
    try:
        return job()
    finally:
        util.HOME.clearProperty(name)


def subtitle_action(action, params=None):
    """Subtitles, spoken language and skip intro (taken over from the Lucent skin)."""
    import subs_live
    if action == "subtitles":
        return subs_live.open_once(auto=False)
    if action == "subs_auto":
        return subs_live.open_once(auto=True)
    if action == "subs_background":
        return _once("lucent.subs.bg", subs_live.background)
    if action == "subs_prefetch":
        import subs_extra
        return _once("lucent.subs.prefetch", subs_extra.prefetch)
    if action in ("subs_earlier", "subs_later"):
        import subs_extra
        step = float((params or {}).get("step") or 0.5)
        return subs_extra.nudge(-step if action == "subs_earlier" else step)
    if action == "subs_other":
        import subs_extra
        return _once("lucent.subs.other", subs_extra.other_subtitle)
    if action == "subs_ready":
        import json
        import subs_extra
        video = json.loads((params or {}).get("video") or "{}")
        return _once("lucent.subs.ahead", lambda: subs_extra.ready_ahead(video)) if video else None
    if action == "subs_key":
        return subs_live.enter_key()
    if action == "subs_mode":
        return subs_live.choose_mode()
    if action == "subs_audio":
        return subs_live.choose_audio()
    if action == "subs_default":
        import subwatch
        return subwatch.set_default()
    if action in ("subs_settings", "skip_settings"):
        return open_settings({"section": action.split("_")[0]})
    import subsetup
    if action == "skip_install":
        return subsetup.install_skip()
    if action == "skip_auto":
        subsetup.toggle_skip_auto()
        return util.notify(subsetup.skip_state())
    return subsetup.wizard(action.split("_")[0])


def open_settings(params):
    """Opens the add-on's settings on one part: general, account, sources, play, library or services."""
    xbmc.executebuiltin("Addon.OpenSettings(%s)" % util.ADDON_ID)
    focus = SECTIONS.get(params.get("section", ""))
    if focus is not None:
        xbmc.sleep(400)
        xbmc.executebuiltin("SetFocus(%d)" % focus)


def trakt_status():
    """Puts the state of the account in Home window properties, for the skin."""
    library.publish_status()


def check_service(module, heading):
    ok, text = module.check()
    xbmcgui.Dialog().ok(heading if ok else T("Niet gelukt", "Failed"), text)


def test():
    ok, text = streams.check()
    xbmcgui.Dialog().ok("AIOStreams" if ok else T("Niet gelukt", "Failed"), text)


FOLDERS = {"people": people, "tmdbmenu": tmdb_menu, "kompasmenu": kompas_menu, "": home, "menu": menu, "tools": tools, "studios": studios, "decades": decades, "awards": awards, "traktmenu": trakt_menu, "traktlists": trakt_lists, "genres": genres,
           "searchmenu": search_menu, "cast": cast, "publiclists": public_lists, "floppylists": floppy_lists, "services": services, "service": service, "mdblistmenu": mdblist_menu, "mdblists": mdblists, "title": title, "list": list_titles, "search": search, "seasons": seasons, "episodes": episodes,
           "easynews_search": easynews_search, "easynews_play": easynews_play, "easynews_pictures": easynews_pictures,
           "collections": collections, "countries": countries}


def run(argv):
    """Runs one call. A button in the settings (…&back=<category>) brings you back to that part of the settings
    afterwards: Kodi closes the settings for such a button, and settings changed while they are open would be lost."""
    params = dict(urllib.parse.parse_qsl((argv[2] if len(argv) > 2 else "").lstrip("?")))
    back = params.get("back", "")
    util.publish_lab()                 # the test blocks in the settings also show when the service is still the old one
    try:
        return _run(argv)
    finally:
        if back in SECTIONS and not xbmc.Player().isPlayingVideo() and not xbmc.getCondVisibility("Window.IsVisible(addonsettings)"):
            open_settings({"section": back})


def _run(argv):
    handle = int(argv[1])
    params = dict(urllib.parse.parse_qsl((argv[2] if len(argv) > 2 else "").lstrip("?")))
    action = params.get("action", "")
    try:
        import subs_builtin
        if subs_builtin.is_subtitle_call(action, params):        # Lucent Video as a subtitle source
            return subs_builtin.search(handle, params)
        if action == "subdownload":
            return subs_builtin.download(handle, params)
        if action in ("play", "seasons") and params.get("tmdb"):
            import kompas
            kompas.opened(params.get("type") or "tvshow", params["tmdb"])
        if action == "play":
            if len(argv) > 3 and argv[3] == "resume:true":
                params["kodi_resumes"] = "1"         # Kodi already asked and starts at the resume point itself
            return player.play(params, handle)
        if action == "auth_trakt":
            linked = trakt.login()
            trakt_status()
            return linked
        if action == "logout_trakt":
            trakt.logout()
            return trakt_status()
        if action == "auth_simkl":
            linked = simkl.login()
            trakt_status()
            return linked
        if action == "logout_simkl":
            simkl.logout()
            return trakt_status()
        if action == "auth_punchplay":
            import punchplay
            linked = punchplay.login()
            trakt_status()
            return linked
        if action == "auth_mdbtrack":
            import mdbtrack
            linked = mdbtrack.login()
            trakt_status()
            return linked
        if action == "logout_mdbtrack":
            import mdbtrack
            mdbtrack.logout()
            return trakt_status()
        if action == "logout_punchplay":
            import punchplay
            punchplay.logout()
            return trakt_status()
        if action == "test_mdblist":
            return check_service(mdblist, "MDBList")
        if action == "report":
            return report.save()
        if action == "poster_test":
            import posters
            return posters.test()
        if action == "poster_refresh":
            import posters
            return posters.refresh()
        if action == "nzb_test":
            from nzb import source as usenet_source
            ok, lines = usenet_source.test()
            return xbmcgui.Dialog().ok("Usenet" if ok else T("Niet alles werkt", "Not everything works"), "\n".join(lines))
        if action == "easynews_preview":
            import dialogs
            return dialogs.show_preview({"preview": params["url"], "name": params.get("name") or ""})
        if action == "test_easynews":
            ok, text = usenet.check_easynews()
            return xbmcgui.Dialog().ok("Easynews" if ok else T("Niet gelukt", "Failed"), text)
        if action == "auth_tmdb":
            import tmdbacct
            return tmdbacct.login()
        if action == "logout_tmdb":
            import tmdbacct
            return tmdbacct.logout()
        if action == "tmdb_actions":
            import tmdbacct
            return tmdbacct.actions(params.get("type", "movie"), params["tmdb"])
        if action == "reviews":
            import tmdbextra
            return tmdbextra.show_reviews(params.get("type", "movie"), params["tmdb"])
        if action == "episode_order":
            import tmdbextra
            return tmdbextra.choose(params["tmdb"])
        if action == "cast_popup":
            import castui
            return castui.open_cast(params.get("type", "movie"), params["tmdb"])
        if action == "pick":
            import pick
            return pick.open_pick()
        if action == "year":
            import year
            return year.open_year()
        if action == "alerts_now":
            import alerts
            return alerts.run()
        if action == "abo_choose":
            import abo
            return abo.choose()
        if action == "learn_forget":
            import learn
            return learn.forget()
        if action == "service_open":
            import services
            return services.open_service(params)
        if action == "backup":
            import backup
            return backup.menu()
        if action == "clear_history":
            util.save_json(EN_HISTORY if params.get("which") == "easynews" else HISTORY, [])
            return xbmc.executebuiltin("Container.Refresh")
        if action == "trailer":
            meta = tmdb.details(params.get("type", "movie"), params["tmdb"])
            if meta and meta.get("trailer"):
                return xbmc.executebuiltin("PlayMedia(%s)" % meta["trailer"])
            return util.notify(T("Geen trailer gevonden", "No trailer found"))
        if action == "remote":
            import remote
            return remote.open_screen()
        if action == "prefetch_now":
            import prefetch
            return prefetch.run()
        if action == "newseason_now":
            import newseason
            return newseason.run()
        if action == "intro_mark":                    # button on the player screen: start / end of a missing intro
            return util.HOME.setProperty("lucent.video.intromark", "1")
        if action == "introskip":
            import introskip
            return introskip.toggle(params["tmdb"])
        if action == "transfer":
            import transfer
            return transfer.run()
        if action == "resume_forget":
            return forget_resume(params)
        if action == "tonight_add":
            import prefetch
            return prefetch.add_tonight(params)
        if action == "account_info":
            import accountinfo
            return accountinfo.show(params.get("service", ""))
        if action == "test_debrid":
            import debrid
            ok, text = debrid.check(params.get("service", ""))
            return xbmcgui.Dialog().ok("Lucent" if ok else T("Niet gelukt", "Failed"), text)
        if action == "test_torbox":
            ok, text = usenet.check_torbox()
            return xbmcgui.Dialog().ok("TorBox" if ok else T("Niet gelukt", "Failed"), text)
        if action == "test_floppy":
            return check_service(floppy, "Floppy")
        if action == "wetrakr_login":
            import wetrakr
            return wetrakr.login()
        if action == "wetrakr_logout":
            import wetrakr
            return wetrakr.logout()
        if action == "views_choose":
            import views
            return views.choose()
        if action == "lists_choose":
            import lists
            return lists.choose()
        if action == "test_homey":
            import homey
            return homey.check()
        if action == "replay":
            import replay
            return replay.run()
        if action == "dual_subs":
            import dualsubs
            return dualsubs.run_now()
        if action == "marathon":
            import marathon
            return marathon.open_card(params["tmdb"])
        if action == "test_tvdb":
            import tvdb
            return tvdb.check()
        if action == "make_testercode":
            import apikeys
            return apikeys.show_code()
        if action == "setup":
            import setup_ui
            return setup_ui.open_setup()
        if action == "who":
            import setup_ui
            return setup_ui.ask_who()
        if action == "ranking":
            import ranking_ui
            return ranking_ui.open_main()
        if action == "settings":
            return open_settings(params)
        if action == "trakt_status":
            return trakt_status()
        if action == "test":
            return test()
        if action == "library_choose":
            if tracker.active() is not trakt:
                return xbmcgui.Dialog().ok("Lucent", T("Kiezen kan alleen met Trakt. Met Simkl gaat alles wat je volgt in de bibliotheek.",
                                                     "Choosing works with Trakt only. With Simkl everything you follow goes in the library."))
            if trakt.choose_library() and xbmcgui.Dialog().yesno("Lucent", T("Bibliotheek nu bijwerken?", "Update the library now?")):
                return library.run(manual=True)
            return None
        if action == "title_menu":
            return title_menu(params)
        if action == "lists":
            import lists
            return lists.open_lists(params.get("type", "movie"), params["tmdb"])
        if action in SUBTITLE_ACTIONS:
            return subtitle_action(action, params)
        if action == "hide_languages":
            import hide
            return hide.choose()
        if action == "nzb_tune":
            from nzb import tune
            return tune.run()
        if action == "library_ctx":            # the Lucent skin's own buttons at the top of the context menu
            import libctx
            return libctx.run(params.get("what", ""), libctx.from_labels(params), libctx.reader(params))
        if action == "season_ready":
            import seasonready
            return seasonready.run(params["tmdb"], params["season"])
        if action == "nzb_stats":
            import stats_ui
            return stats_ui.run()
        if action == "sources_lang":
            import mylang
            return mylang.choose()
        if action == "trakt_refresh":                # for the skin: renew the Trakt login quietly when needed
            util.OVERRIDE_USER = users.MAIN          # the skin reads the file of the first profile
            try:
                if trakt.logged_in():
                    trakt.refresh_quietly()
            finally:
                util.OVERRIDE_USER = None
            return None
        if action == "widgets_refresh":
            import widgets
            return widgets.refresh_all()
        if action == "library_add":
            return library.add_one(params.get("type", "movie"), params["tmdb"])
        if action == "library_remove":
            return library.remove_one(params.get("type", "movie"), params["tmdb"])
        if action == "library_skip":
            return library.skip(params["tmdb"], params["season"], params.get("episode"))
        if action == "library_status":
            return library.publish_counts()
        if action.startswith("kompas_"):
            import kompas
            return kompas.action(action, params)
        if action == "library_sync":
            return library.run(manual=True)
        if action == "clear_cache":
            util.cache_clear()
            return util.notify(T("Cache gewist", "Cache cleared"))
        if action == "watched":
            return set_watched(params)
        if action == "watchlist":
            return set_watchlist(params)
        if action == "":
            import setup_ui
            if setup_ui.needed():
                setup_ui.open_setup()
            if len(users.everyone()) > 1 and not util.HOME.getProperty("lucent.video.who.asked"):
                util.HOME.setProperty("lucent.video.who.asked", "1")
                setup_ui.ask_who()
        if not tmdb.key() and action not in ("tools", ""):
            if params.get("widget") == "1":      # a row on Home: stay empty, never open a window
                return xbmcplugin.endOfDirectory(handle, succeeded=False)
            xbmcgui.Dialog().ok("Lucent", T("Vul eerst je TMDB-sleutel in bij de instellingen.", "Enter your TMDB key in the settings first."))
            return xbmcplugin.endOfDirectory(handle, succeeded=False)
        return FOLDERS[action](handle, params)
    except util.HttpError as error:
        util.log("%s: %s" % (action, error), xbmc.LOGERROR)
        util.notify(T("Ophalen is niet gelukt", "Could not load this"))
    except KeyError as error:
        util.log("%s: missing %s" % (action, error), xbmc.LOGERROR)
    if action in FOLDERS and handle >= 0:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
    return None
